import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Stars, Text } from '@react-three/drei'
import * as THREE from 'three'

// Data point component
function ExpensePoint({ amount, category, position }) {
  const ref = useRef()
  const color = {
    food: '#f87171',    // Red-400
    travel: '#60a5fa',  // Blue-400 
    shopping: '#34d399' // Green-400
  }[category]

  useFrame(({ clock }) => {
    ref.current.position.y = position[1] + Math.sin(clock.getElapsedTime()) * 0.3
  })

  return (
    <mesh position={position} ref={ref}>
      <sphereGeometry args={[amount / 500, 16, 16]} />
      <meshStandardMaterial color={color} />
      <Text
        position={[0, 0, 0.5]}
        fontSize={0.2}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {`₹${amount}`}
      </Text>
    </mesh>
  )
}

// Main globe component
export default function ExpenseGlobe({ expenses }) {
  const getPosition = (index, total) => {
    const phi = Math.acos(-1 + (2 * index) / total)
    const theta = Math.sqrt(total * Math.PI) * phi
    return [
      5 * Math.cos(theta) * Math.sin(phi),
      5 * Math.sin(theta) * Math.sin(phi),
      5 * Math.cos(phi)
    ]
  }

  return (
    <div className="h-[400px] w-full">
      <Canvas camera={{ position: [0, 0, 10], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <Stars radius={100} depth={50} count={1000} factor={4} />
        
        {expenses.map((expense, i) => (
          <ExpensePoint
            key={i}
            amount={expense.amount}
            category={expense.category}
            position={getPosition(i, expenses.length)}
          />
        ))}
        
        <OrbitControls
          autoRotate
          autoRotateSpeed={2}
          enableZoom={false}
        />
      </Canvas>
    </div>
  )
}
