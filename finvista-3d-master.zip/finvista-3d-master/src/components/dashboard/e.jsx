import { useState, useEffect } from 'react'
import { collection, query, where, onSnapshot } from 'firebase/firestore'
import { auth, db } from '../../firebase/firebaseConfig'
import ExpenseGlobe from '../../components/dashboard/ExpenseGlobe'

export default function Dashboard() {
  const [expenses, setExpenses] = useState([])

  useEffect(() => {
    if (!auth.currentUser) return
    
    const q = query(
      collection(db, 'expenses'),
      where('userId', '==', auth.currentUser.uid)
    )
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }))
      setExpenses(data)
    })

    return () => unsubscribe()
  }, [])

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Your Spending Globe</h1>
      <ExpenseGlobe expenses={expenses} />
    </div>
  )
}