import { Pie } from "react-chartjs-2";

function SpendingChart({ expenses }) {
  const data = {
    labels: ["Food", "Travel", "Entertainment"],
    datasets: [{
      data: [300, 500, 200],
      backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"]
    }]
  };

  return (
    <div style={{ width: "400px" }}>
      <Pie data={data} />
    </div>
  );
}
