// src/components/layout/AppLayout.jsx
import Sidebar from './Sidebar';
import MainContent from './MainContent';

export default function AppLayout() {
  return (
    <div className="flex h-screen">
      <Sidebar />
      <MainContent />
    </div>
  );
}