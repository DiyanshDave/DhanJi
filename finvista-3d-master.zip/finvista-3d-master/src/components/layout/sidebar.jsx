// src/components/layout/Sidebar.jsx
import { NavLink } from 'react-router-dom';
import { FiHome, FiPieChart, FiDollarSign, FiSettings } from 'react-icons/fi';

export default function Sidebar() {
  return (
    <div className="w-64 bg-white shadow-lg">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-blue-600 flex items-center">
          <FiDollarSign className="mr-2" />
          FinVista 3D
        </h1>
      </div>
      <nav className="mt-6">
        {[
          { to: '/', icon: <FiHome />, text: 'Dashboard' },
          { to: '/expenses', icon: <FiPieChart />, text: 'Expenses' },
          { to: '/analytics', icon: <FiPieChart />, text: 'Analytics' },
          { to: '/settings', icon: <FiSettings />, text: 'Settings' }
        ].map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => 
              `flex items-center px-6 py-3 ${isActive ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-100'}`
            }
          >
            <span className="mr-3">{item.icon}</span>
            {item.text}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}