// src/components/layout/MainContent.jsx
import { Outlet } from 'react-router-dom';
import ExpenseGlobe from '../dashboard/ExpenseGlobe';

export default function MainContent() {
  return (
    <div className="flex-1 overflow-auto p-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 3D Globe Visualization */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-md p-6">
          <ExpenseGlobe />
        </div>
        <div className="lg:col-span-2 backdrop-blur-lg bg-white/30 rounded-xl shadow-lg p-6 border border-white/20">
  <ExpenseGlobe />
</div>  
        
        {/* Summary Cards */}
        <div className="space-y-6">
          {['Total Spending', 'Budget Left', 'Top Category'].map((item) => (
            <div key={item} className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-gray-500">{item}</h3>
              <p className="text-2xl font-bold mt-2">$2,450</p>
            </div>
          ))}
        </div>
      </div>
      
      {/* Recent Transactions */}
      <div className="mt-8 bg-white rounded-xl shadow-md p-6">
        <Outlet /> {/* This renders nested routes */}
      </div>
    </div>
  );
}
// Wrap components with Framer Motion
import { motion } from 'framer-motion';

<motion.div
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  transition={{ duration: 0.5 }}
>
  {/* Your content */}
</motion.div>