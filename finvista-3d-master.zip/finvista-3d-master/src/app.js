// function App() {
//     return (
//       <div className="min-h-screen bg-gray-100 md:p-10">
//         <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-2xl">
//           {/* Your components here */}
//         </div>
//       </div>
//     );
//   }
import { Suspense } from 'react';
import { Toaster } from 'react-hot-toast';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoadingSpinner from './components/ui/LoadingSpinner';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import ErrorBoundary from './components/error/ErrorBoundary';

// Lazy-loaded pages for better performance
const HomePage = React.lazy(() => import('./pages/HomePage'));
const DashboardPage = React.lazy(() => import('./pages/DashboardPage'));
const ExpensesPage = React.lazy(() => import('./pages/ExpensesPage'));

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100 flex flex-col">
        {/* Navigation */}
        <Navbar />
        
        {/* Main Content */}
        <main className="flex-1 container mx-auto p-4 md:p-6 lg:p-8">
          <ErrorBoundary>
            <Suspense fallback={<LoadingSpinner fullScreen />}>
              <div className="max-w-7xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/expenses" element={<ExpensesPage />} />
                  <Route path="*" element={<NotFoundPage />} />
                </Routes>
              </div>
            </Suspense>
          </ErrorBoundary>
        </main>

        {/* Footer */}
        <Footer />

        {/* Global Toaster for notifications */}
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
          }}
        />
      </div>
    </Router>
  );
}

export default App;