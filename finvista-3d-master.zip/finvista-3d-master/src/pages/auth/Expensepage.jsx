// src/pages/ExpensesPage.jsx
import ExpenseList from '../components/expenses/ExpenseList';

export default function ExpensesPage() {
  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <h1 className="text-3xl font-bold mb-8 text-blue-600">Your Expenses</h1>
      <ExpenseList />
    </div>
  );
}