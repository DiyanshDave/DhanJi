import { 
    auth, 
    googleProvider,
    db 
  } from './firebaseConfig';
  import { 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword, 
    signInWithPopup, 
    signOut 
  } from 'firebase/auth';
  import { doc, setDoc } from 'firebase/firestore';
  
  // Email/password signup
  export const signUpWithEmail = async (email, password, name) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      
      await setDoc(doc(db, "users", userCredential.user.uid), {
        email: email,
        name: name,
        createdAt: new Date(),
        totalExpenses: 0
      });
      
      return userCredential;
    } catch (error) {
      throw error;
    }
  };
  
  // Email/password login
  export const logInWithEmail = async (email, password) => {
    try {
      return await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
      throw error;
    }
  };
  
  // Google sign-in
  export const signInWithGoogle = async () => {
    try {
      const userCredential = await signInWithPopup(auth, googleProvider);
      
      const userDoc = doc(db, "users", userCredential.user.uid);
      await setDoc(userDoc, {
        email: userCredential.user.email,
        name: userCredential.user.displayName,
        createdAt: new Date(),
        totalExpenses: 0
      }, { merge: true });
      
      return userCredential;
    } catch (error) {
      throw error;
    }
  };
  
  // Sign out
  export const signOutUser = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      throw error;
    }
  };