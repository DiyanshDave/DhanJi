// src/firebase/expenseService.js
import { db } from './firebaseConfig';
import { 
  collection, 
  addDoc, 
  getDocs, 
  doc, 
  updateDoc, 
  deleteDoc,
  query,
  where,
  orderBy
} from 'firebase/firestore';
import { auth } from './firebaseConfig';

// Create
export const addExpense = async (expenseData) => {
  try {
    const user = auth.currentUser;
    if (!user) throw new Error('User not authenticated');
    
    const expenseWithMetadata = {
      ...expenseData,
      userId: user.uid,
      createdAt: new Date().toISOString(),
      amount: Number(expenseData.amount) // Ensure amount is stored as number
    };
    
    const docRef = await addDoc(collection(db, 'expenses'), expenseWithMetadata);
    return { id: docRef.id, ...expenseWithMetadata };
  } catch (error) {
    console.error("Error adding expense: ", error);
    throw error;
  }
};

// Read (All expenses for current user)
export const getExpenses = async () => {
  const user = auth.currentUser;
  if (!user) return [];

  const q = query(
    collection(db, 'expenses'),
    where('userId', '==', user.uid),
    orderBy('createdAt', 'desc')
  );

  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
};

// Update
export const updateExpense = async (expenseId, updatedData) => {
  try {
    const expenseRef = doc(db, 'expenses', expenseId);
    await updateDoc(expenseRef, updatedData);
  } catch (error) {
    console.error("Error updating expense: ", error);
    throw error;
  }
};

// Delete
export const deleteExpense = async (expenseId) => {
  try {
    const expenseRef = doc(db, 'expenses', expenseId);
    await deleteDoc(expenseRef);
  } catch (error) {
    console.error("Error deleting expense: ", error);
    throw error;
  }
};